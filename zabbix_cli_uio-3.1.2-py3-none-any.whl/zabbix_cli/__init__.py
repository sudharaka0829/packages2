from __future__ import annotations

from zabbix_cli._patches import patch_all

patch_all()
